// Background service worker — TrustCheck AI
// In production this would call a backend LLM (Gemini / Claude).

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "analyze_product") {
    setTimeout(() => {
      sendResponse(mockAiAnalysis(request.data));
    }, 1500);
    return true;
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM TIER SYSTEM
//
//  curated    — Myntra, Ajio: closed marketplace, every brand is pre-vetted,
//               platform runs own logistics. Low review volume is NORMAL here.
//               Trust comes from platform curation, not crowd reviews.
//
//  managed    — Flipkart (Ekart), Amazon fulfilled-by-Amazon / first-party:
//               Platform controls delivery end-to-end. Review volume matters
//               but platform infrastructure provides a baseline trust floor.
//
//  open       — Amazon 3P sellers, eBay, unknown sites:
//               No platform guarantee. Review volume is the primary trust signal.
//               Low volume = high risk.
// ─────────────────────────────────────────────────────────────────────────────
const PLATFORM_TIERS = {
  Myntra:   'curated',
  Ajio:     'curated',
  Flipkart: 'managed',
  Amazon:   'managed',   // refined further by seller name check below
};

function getPlatformTier(platform, seller) {
  const tier = PLATFORM_TIERS[platform] || 'open';
  // Demote Amazon to 'open' for third-party sellers without known fulfillers
  if (platform === 'Amazon' && tier === 'managed') {
    const s = (seller || '').toLowerCase();
    const isFulfilled =
      s.includes('amazon') || s.includes('appario') || s.includes('retailnet') ||
      s.includes('cocoblu') || s.includes('clicktech') || s.includes('supercomnet');
    return isFulfilled ? 'managed' : 'open';
  }
  return tier;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN ANALYSIS
// ─────────────────────────────────────────────────────────────────────────────
function mockAiAnalysis(data) {
  let trustScore = 50;
  let reasoning  = [];

  const platform = data.platform || '';
  const seller   = data.seller   || '';
  const tier     = getPlatformTier(platform, seller);

  // Parse review data early — used throughout
  const reviewText  = data.reviewCount || '';
  const parsedCount = parseInt(reviewText.replace(/[^0-9]/g, '')) || 0;
  const ratingNum   = parseFloat(data.rating);
  const hasRating   = !isNaN(ratingNum) && parsedCount > 0;

  // ── 1. Platform Check ──────────────────────────────────────────────
  if (tier === 'curated') {
    trustScore += 20;
    reasoning.push(
      `${platform} is a curated fashion marketplace — every brand is pre-vetted before listing. ` +
      `Platform trust is based on brand verification, not review volume.`
    );
  } else if (tier === 'managed') {
    trustScore += 10;
    reasoning.push(
      `${platform} provides structured buyer protection, managed logistics, and enforced return policies.`
    );
  } else {
    const knownMajor = ['Amazon', 'Flipkart'].includes(platform);
    if (knownMajor) {
      trustScore += 5;
      reasoning.push(`${platform} provides some buyer protection, but this third-party seller is not directly verified.`);
    } else {
      trustScore -= 15;
      reasoning.push(`Platform "${platform}" provides limited verification. Exercise caution.`);
    }
  }

  // ── 2. Seller Check ────────────────────────────────────────────────
  if (tier === 'curated') {
    trustScore += 10;
    reasoning.push(`Brand "${seller}" is an approved ${platform} partner — listings are authentic by design.`);
  } else if (tier === 'managed') {
    trustScore += 10;
    reasoning.push(`Seller (${seller}) ships via ${platform}'s managed fulfilment network.`);
  } else {
    const s = seller.toLowerCase();
    if (s && s !== 'unknown') {
      reasoning.push(`Third-party seller "${seller}" — authenticity depends on review volume and rating.`);
    } else {
      trustScore -= 25;
      reasoning.push(`Seller identity hidden or unknown. Major red flag for counterfeit or drop-shipping.`);
    }
  }

  // ── 3. Review Volume & Rating ──────────────────────────────────────
  if (tier === 'curated') {
    // Curated platforms have inherently lower review volumes per SKU.
    // We treat reviews as a signal but DON'T penalise low volume.
    if (!hasRating) {
      reasoning.push(
        `No reviews yet — new listings on ${platform} are normal without reviews since trust comes from brand verification.`
      );
    } else if (parsedCount < 20) {
      reasoning.push(
        `${parsedCount} reviews at ${ratingNum}⭐. Low counts are common on ${platform} for niche fashion SKUs — the platform's curation is the primary quality signal.`
      );
    } else {
      // Some volume — good additional signal
      trustScore += 5;
      if (ratingNum >= 4.0) {
        trustScore += 10;
        reasoning.push(`${parsedCount} reviews at ${ratingNum}⭐. Buyers are broadly satisfied.`);
      } else if (ratingNum < 3.5) {
        trustScore -= 15;
        reasoning.push(`Rating of ${ratingNum}⭐ across ${parsedCount} reviews — worth reading complaints before purchasing.`);
      } else {
        reasoning.push(`${parsedCount} reviews at ${ratingNum}⭐ — mixed but acceptable for fashion items.`);
      }
    }
  } else {
    // Open / Managed: volume IS the trust signal
    if (!hasRating) {
      trustScore -= 30;
      reasoning.push(`No verified reviews found. Zero review volume on an open marketplace is a strong scam indicator.`);
    } else {
      if (parsedCount < 10) {
        trustScore -= 20;
        reasoning.push(`Only ${parsedCount} reviews — dangerously low. Ratings this thin are trivially easy to fabricate.`);
      } else if (parsedCount < 50) {
        trustScore -= 5;
        reasoning.push(`Low review volume (${parsedCount}). Insufficient data to verify rating authenticity.`);
      } else if (parsedCount < 200) {
        trustScore += 10;
        reasoning.push(`Moderate review volume (${parsedCount}). Ratings carry reasonable credibility at this count.`);
      } else if (parsedCount < 1000) {
        trustScore += 20;
        reasoning.push(`Substantial review volume (${parsedCount}). Ratings likely reflect genuine buyer experiences.`);
      } else {
        trustScore += 30;
        reasoning.push(`Extensive review volume (${parsedCount}+). A well-established, genuine listing.`);
      }

      if (ratingNum >= 4.5) {
        trustScore += 15;
        reasoning.push(`Rating of ${ratingNum}⭐ — buyers are highly satisfied.`);
      } else if (ratingNum >= 4.0) {
        trustScore += 10;
        reasoning.push(`Rating of ${ratingNum}⭐ — consistent buyer satisfaction.`);
      } else if (ratingNum < 3.5) {
        trustScore -= 20;
        reasoning.push(`Rating of ${ratingNum}⭐ — frequent buyer complaints reported.`);
      }
    }
  }

  // ── 4. Title Scam Heuristics (applies to all tiers) ───────────────
  if (data.title) {
    const t = data.title.toLowerCase();
    if (t.length > 120) {
      trustScore -= 10;
      reasoning.push(`Title is excessively keyword-stuffed — common in counterfeit listings.`);
    }
    if (t.includes('[original]') || t.includes('100% genuine')) {
      trustScore -= 20;
      reasoning.push(`Title uses "[Original]" or "100% Genuine" — authentic brands rarely self-certify this way.`);
    }
    const typoRegex = /\b(budss|cmff|airpodds|iphonn|sammsung|appple)\b/i;
    if (typoRegex.test(t)) {
      trustScore -= 30;
      reasoning.push(`Title contains suspicious brand misspellings — a confirmed counterfeit technique.`);
    }
  }

  // ── 5. Discount Check ──────────────────────────────────────────────
  let discountNum = 0;
  if (data.discount) {
    discountNum = parseInt(data.discount.replace(/[^0-9]/g, '')) || 0;
  }

  if (tier === 'curated') {
    // Myntra / Ajio regularly run 40–70%+ sale events — this is expected
    if (discountNum > 80) {
      trustScore -= 5;
      reasoning.push(`Unusually high discount (${discountNum}%). Even for ${platform} sale events, verify this is a genuine markdown.`);
    }
  } else {
    if (discountNum > 60 && parsedCount < 50) {
      trustScore -= 25;
      reasoning.push(`Massive discount (${discountNum}%) with almost no reviews — classic fake listing tactic.`);
    } else if (discountNum > 70) {
      trustScore -= 10;
      reasoning.push(`Suspiciously high discount (${discountNum}%). Unlikely for genuine products.`);
    }
  }

  trustScore = Math.max(1, Math.min(99, trustScore));

  const deliveryTrust = analyzeDeliveryAndReturns(data, tier, trustScore, parsedCount, ratingNum, hasRating);

  return {
    trustScore,
    reasoning: reasoning.join(' '),
    delivery: deliveryTrust
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// DELIVERY / RETURNS / REFUND ANALYSIS  — tier-aware
// ─────────────────────────────────────────────────────────────────────────────
function analyzeDeliveryAndReturns(data, tier, trustScore, parsedCount, ratingNum, hasRating) {
  const platform = data.platform || '';
  const seller   = (data.seller || '').toLowerCase();

  // ── Star calculator — tier-aware ──────────────────────────────────
  // Curated platforms: low volume doesn't drag stars down sharply
  // because the platform's curation is the baseline quality signal.
  function calcStars(bonus = 0) {
    if (!hasRating) {
      // Curated: no reviews → mid floor (platform guarantees minimum quality)
      // Open:    no reviews → suspicious floor
      return tier === 'curated' ? 3.0 : 1.0;
    }

    const base = Math.min(ratingNum, 5);

    let vol;
    if (tier === 'curated') {
      // Volume multipliers are lenient for curated platforms.
      // Even 1 review can be meaningful on a pre-vetted platform.
      if (parsedCount === 0)       vol = 0.80; // shouldn't reach here but safe fallback
      else if (parsedCount < 10)   vol = 0.82;
      else if (parsedCount < 50)   vol = 0.88;
      else if (parsedCount < 200)  vol = 0.94;
      else                         vol = 1.00;
    } else if (tier === 'managed') {
      // Managed: platform controls logistics so volume matters less than open
      if (parsedCount < 10)        vol = 0.60;
      else if (parsedCount < 50)   vol = 0.72;
      else if (parsedCount < 200)  vol = 0.84;
      else if (parsedCount < 1000) vol = 0.94;
      else                         vol = 1.00;
    } else {
      // Open: volume is king
      if (parsedCount < 10)        vol = 0.45;
      else if (parsedCount < 50)   vol = 0.58;
      else if (parsedCount < 200)  vol = 0.76;
      else if (parsedCount < 1000) vol = 0.92;
      else                         vol = 1.00;
    }

    let stars = base * vol + bonus;
    return Math.round(Math.max(1, Math.min(5, stars)) * 2) / 2;
  }

  // Amazon FBA / first-party delivery bonus
  const isFBADelivery = platform === 'Amazon' && (
    seller.includes('amazon') || seller.includes('appario') || seller.includes('cocoblu') ||
    seller.includes('clicktech') || seller.includes('retailnet')
  );

  const deliveryStars = calcStars(isFBADelivery ? 0.4 : 0);
  const returnStars   = calcStars(['Amazon','Flipkart','Myntra','Ajio'].includes(platform) ? 0.2 : 0);
  const refundStars   = calcStars(0);

  // ── Delivery label ─────────────────────────────────────────────────
  let deliveryLabel, deliveryStatus, deliveryNote;

  if (tier === 'curated') {
    // Platform runs own logistics — evaluate on rating, not volume
    if (!hasRating) {
      deliveryLabel = 'Platform Managed';
      deliveryStatus = 'ok';
      deliveryNote = `${platform} handles all deliveries through its own logistics. No individual item reviews yet, but platform-level delivery is tracked.`;
    } else if (ratingNum >= 4.0) {
      deliveryLabel = 'On Time';
      deliveryStatus = 'ok';
      deliveryNote = `${platform}'s in-house logistics ${parsedCount > 0 ? `and ${parsedCount} buyer reviews at ${ratingNum}⭐ ` : ''}indicate timely, trackable delivery.`;
    } else if (ratingNum >= 3.2) {
      deliveryLabel = 'Generally On Time';
      deliveryStatus = 'ok';
      deliveryNote = `Rating of ${ratingNum}⭐${parsedCount > 0 ? ` across ${parsedCount} reviews` : ''}. Delivery is managed by ${platform} — occasional delays possible.`;
    } else {
      deliveryLabel = 'Some Complaints';
      deliveryStatus = 'bad';
      deliveryNote = `Rating of ${ratingNum}⭐${parsedCount > 0 ? ` across ${parsedCount} reviews` : ''}. Despite platform logistics, some buyers have flagged delivery issues.`;
    }
  } else if (tier === 'managed') {
    if (!hasRating) {
      deliveryLabel = 'Logistics Managed';
      deliveryStatus = 'ok';
      deliveryNote = `${isFBADelivery ? 'Fulfilled by Amazon' : `${platform} managed`} — delivery is handled by the platform, not the seller.`;
    } else if (parsedCount < 10) {
      deliveryLabel = 'Limited Signals';
      deliveryStatus = 'ok';
      deliveryNote = `Only ${parsedCount} reviews. Platform manages delivery so seller-level data is less critical here.`;
    } else if (ratingNum >= 4.2) {
      deliveryLabel = 'Reliable Track Record';
      deliveryStatus = 'ok';
      deliveryNote = `${parsedCount} buyers at ${ratingNum}⭐ — delivery consistently rated as satisfactory.`;
    } else if (ratingNum >= 3.5) {
      deliveryLabel = 'Moderate Consistency';
      deliveryStatus = 'ok';
      deliveryNote = `${ratingNum}⭐ across ${parsedCount} reviews. Some variability expected.`;
    } else {
      deliveryLabel = 'Documented Complaints';
      deliveryStatus = 'bad';
      deliveryNote = `${ratingNum}⭐ with ${parsedCount} reviews. Buyers have raised delivery concerns despite managed logistics.`;
    }
  } else {
    // Open
    if (!hasRating) {
      deliveryLabel = 'Unverified';
      deliveryStatus = 'bad';
      deliveryNote = 'No reviews to assess delivery. Treat as unverified.';
    } else if (parsedCount < 10) {
      deliveryLabel = 'Suspicious';
      deliveryStatus = 'bad';
      deliveryNote = `Only ${parsedCount} reviews — too few to draw conclusions about delivery.`;
    } else if (parsedCount < 50) {
      deliveryLabel = ratingNum >= 4.0 ? 'Limited Data' : 'Mixed Signals';
      deliveryStatus = ratingNum >= 4.0 ? 'ok' : 'bad';
      deliveryNote = ratingNum >= 4.0
        ? `Rated ${ratingNum}⭐ but only ${parsedCount} reviews. May not be representative.`
        : `Low rating (${ratingNum}⭐) with few reviews (${parsedCount}). Delivery consistency is questionable.`;
    } else if (ratingNum >= 4.2) {
      deliveryLabel = 'Mostly On Time';
      deliveryStatus = 'ok';
      deliveryNote = `${parsedCount} reviews at ${ratingNum}⭐ — buyers broadly satisfied with delivery.`;
    } else if (ratingNum >= 3.5) {
      deliveryLabel = 'Inconsistent';
      deliveryStatus = 'ok';
      deliveryNote = `${ratingNum}⭐ across ${parsedCount} reviews. Delivery experience varies by order.`;
    } else {
      deliveryLabel = 'Frequent Issues';
      deliveryStatus = 'bad';
      deliveryNote = `${ratingNum}⭐ with ${parsedCount} reviews. Buyers report delivery problems.`;
    }
  }

  // ── Returns label ──────────────────────────────────────────────────
  let returnLabel, returnStatus, returnNote;

  const platformReturnWindow = {
    Amazon: '10-Day Returns', Flipkart: '7-Day Returns',
    Myntra: '14-Day Returns', Ajio:    '15-Day Returns'
  };
  const returnWindow = platformReturnWindow[platform];

  if (!returnWindow) {
    if (trustScore < 40) {
      returnLabel = 'No Clear Policy'; returnStatus = 'bad';
      returnNote  = 'Unverified platform. Return requests may go unanswered.';
    } else {
      returnLabel = 'Policy Unclear'; returnStatus = 'ok';
      returnNote  = 'Return terms not verified. Check before purchasing.';
    }
  } else if (tier === 'curated') {
    // Myntra / Ajio returns are enforced by the platform, not the seller
    if (!hasRating || parsedCount < 5) {
      returnLabel = returnWindow;
      returnStatus = 'ok';
      returnNote = `${platform} enforces its own return policy directly. The ${returnWindow} window applies platform-wide regardless of individual seller reviews.`;
    } else if (ratingNum < 3.5 && parsedCount >= 20) {
      returnLabel = `${returnWindow} — Check Reviews`;
      returnStatus = 'ok';
      returnNote = `Policy is platform-enforced (${returnWindow}), but ${ratingNum}⭐ rating suggests some buyers faced friction. Read recent reviews.`;
    } else {
      returnLabel = returnWindow;
      returnStatus = 'ok';
      returnNote = `${platform} directly manages returns. The ${returnWindow} policy is platform-enforced and doesn't depend on individual seller behaviour.`;
    }
  } else if (!hasRating || parsedCount === 0) {
    returnLabel = `${returnWindow} — Unverified`; returnStatus = 'bad';
    returnNote  = `Policy exists but no reviews confirm this seller honours it.`;
  } else if (parsedCount < 10) {
    returnLabel = `${returnWindow} — Sparse Data`; returnStatus = 'bad';
    returnNote  = `Only ${parsedCount} reviews. Can't confirm return compliance.`;
  } else if (ratingNum < 3.5 && parsedCount >= 50) {
    returnLabel = `${returnWindow} — Disputed`; returnStatus = 'bad';
    returnNote  = `Low rating (${ratingNum}⭐) at volume suggests return friction despite the policy.`;
  } else if (parsedCount >= 200 && ratingNum >= 4.0) {
    returnLabel = returnWindow; returnStatus = 'ok';
    returnNote  = `${parsedCount} reviews at ${ratingNum}⭐ — returns processed as expected.`;
  } else {
    returnLabel = `${returnWindow} — Partially Verified`; returnStatus = 'ok';
    returnNote  = `Policy applies. ${parsedCount} reviews provide partial confirmation.`;
  }

  // ── Refund label ───────────────────────────────────────────────────
  let refundLabel, refundStatus, refundNote;

  const refundTimeline = {
    Amazon:   '3–5 business days',
    Flipkart: '5–7 business days',
    Myntra:   '7–10 days or instant wallet',
    Ajio:     '7–10 days or instant wallet'
  }[platform];

  if (!refundTimeline) {
    if (trustScore < 40) {
      refundLabel = 'High Refund Risk'; refundStatus = 'bad';
      refundNote  = 'Low-trust platform. Prefer cash-on-delivery if possible.';
    } else {
      refundLabel = 'Unconfirmed'; refundStatus = 'ok';
      refundNote  = 'Refund process not verified for this platform.';
    }
  } else if (tier === 'curated') {
    // Refunds are centralised — platform processes them, not the brand
    if (!hasRating || parsedCount < 5) {
      refundLabel = refundTimeline.includes('wallet') ? 'Instant Wallet / Refund' : `Within ${refundTimeline}`;
      refundStatus = 'ok';
      refundNote = `${platform} processes refunds centrally (${refundTimeline}). Not reliant on individual brand cooperation.`;
    } else if (ratingNum < 3.5 && parsedCount >= 20) {
      refundLabel = `${refundTimeline} — Check Reviews`;
      refundStatus = 'ok';
      refundNote = `Refunds are platform-managed, but ${ratingNum}⭐ rating warrants reviewing recent buyer comments.`;
    } else {
      refundLabel = refundTimeline.includes('wallet') ? 'Instant Wallet / Refund' : `Within ${refundTimeline}`;
      refundStatus = 'ok';
      refundNote = `${platform} manages refunds end-to-end (${refundTimeline}). Platform-level track record is established.`;
    }
  } else if (!hasRating || parsedCount === 0) {
    refundLabel = 'No Review Basis'; refundStatus = 'bad';
    refundNote  = `Expected within ${refundTimeline} but no reviews confirm this seller follows through.`;
  } else if (parsedCount < 10) {
    refundLabel = 'Unverifiable'; refundStatus = 'bad';
    refundNote  = `Only ${parsedCount} reviews — can't determine refund reliability.`;
  } else if (ratingNum < 3.5 && parsedCount >= 50) {
    refundLabel = 'Likely Disputed'; refundStatus = 'bad';
    refundNote  = `${ratingNum}⭐ with ${parsedCount} reviews — buyers may have experienced refund friction.`;
  } else if (parsedCount >= 200 && ratingNum >= 4.0) {
    refundLabel = `Within ${refundTimeline}`; refundStatus = 'ok';
    refundNote  = `Strong review volume at ${ratingNum}⭐ suggests minimal refund friction.`;
  } else {
    refundLabel = `~${refundTimeline}`; refundStatus = 'ok';
    refundNote  = `Platform policy applies. ${parsedCount} reviews provide partial confirmation.`;
  }

  return {
    delivery: { label: deliveryLabel, status: deliveryStatus, note: deliveryNote, stars: deliveryStars },
    returns:  { label: returnLabel,   status: returnStatus,   note: returnNote,   stars: returnStars  },
    refund:   { label: refundLabel,   status: refundStatus,   note: refundNote,   stars: refundStars  }
  };
}
