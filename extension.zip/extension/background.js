// Background service worker — TrustCheck AI
// Analyzes reviews directly from the scraped content.

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "analyze_product") {
    setTimeout(() => {
      sendResponse(mockAiAnalysis(request.data));
    }, 1500);
    return true;
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM TIER SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
const PLATFORM_TIERS = {
  Myntra:   'curated',
  Ajio:     'curated',
  Flipkart: 'managed',
  Amazon:   'managed',
};

function getPlatformTier(platform, seller) {
  const tier = PLATFORM_TIERS[platform] || 'open';
  if (platform === 'Amazon' && tier === 'managed') {
    const s = (seller || '').toLowerCase();
    const isFulfilled =
      s.includes('amazon') || s.includes('appario') || s.includes('retailnet') ||
      s.includes('cocoblu') || s.includes('clicktech') || s.includes('supercomnet');
    return isFulfilled ? 'managed' : 'open';
  }
  return tier;
}

// ─────────────────────────────────────────────────────────────────────────────
// DIRECT REVIEW CONTENT ANALYSIS
// ─────────────────────────────────────────────────────────────────────────────
function analyzeReviewContent(reviews) {
  if (!reviews || reviews.length === 0) {
    return { scoreModifier: 0, reasoning: [], cons: [] };
  }

  let positiveWords = ['good', 'great', 'excellent', 'amazing', 'perfect', 'nice', 'awesome', 'best', 'love', 'genuine', 'happy', 'satisfied'];
  let negativeWords = ['bad', 'worst', 'terrible', 'fake', 'poor', 'defective', 'damaged', 'useless', 'broken', "don't buy", 'waste', 'disappointed'];
  
  let fakePhrases = ['highly recommend', 'best product ever', 'totally worth', 'as described', '100% genuine', 'must buy', 'excellent product'];

  let concernRegexes = {
    'Durability/Build Issues': /broken|tear|tore|ripped|fragile|lasted|stopped working|loose|tight/i,
    'Size/Fit Issues': /small|large|fit/i,
    'Battery/Power': /battery|charge|drain/i,
    'Delivery Issues': /late|delayed|damage|package/i,
    'Fake/Counterfeit': /fake|counterfeit|copy|duplicate/i,
    'Customer Service': /support|refund|return|service/i
  };

  let reviewCount = reviews.length;
  let positiveCount = 0;
  let negativeCount = 0;
  let fakeCount = 0;
  let shortCount = 0;
  let exclamationCount = 0;
  let foundCons = new Set();
  
  for (let i = 0; i < reviews.length; i++) {
    let r = reviews[i].toLowerCase();
    
    // Sentiment
    let isPos = positiveWords.some(w => r.includes(w));
    let isNeg = negativeWords.some(w => r.includes(w));
    if (isPos && !isNeg) positiveCount++;
    if (isNeg) negativeCount++;

    // Fake Phrases
    if (fakePhrases.some(w => r.includes(w))) fakeCount++;

    // Short / Vague
    let words = r.split(' ').filter(w => w.trim().length > 0);
    if (words.length < 8) shortCount++;

    // Exclamation
    let exclamations = (r.match(/!/g) || []).length;
    exclamationCount += exclamations;

    // Concerns
    for (const [concern, regex] of Object.entries(concernRegexes)) {
      if (regex.test(r)) foundCons.add(concern);
    }
  }

  // Duplicate Check (Jaccard similarity)
  let duplicates = 0;
  for (let i = 0; i < reviews.length; i++) {
    for (let j = i + 1; j < reviews.length; j++) {
      let r1 = reviews[i].toLowerCase().split(' ').filter(w => w.length > 3);
      let r2 = reviews[j].toLowerCase().split(' ').filter(w => w.length > 3);
      if (r1.length < 3 || r2.length < 3) continue;
      
      let intersection = r1.filter(x => r2.includes(x));
      let union = new Set([...r1, ...r2]);
      let jaccard = intersection.length / union.size;
      
      if (jaccard > 0.65) duplicates++;
    }
  }

  let modifier = 0;
  let reasoning = [];

  // 1. Sentiment Ratio modifier (-15 to +15)
  let sentimentRatio = (positiveCount - negativeCount) / reviewCount;
  modifier += (sentimentRatio * 15);
  if (negativeCount > positiveCount) {
    reasoning.push(`High proportion of negative review text detected.`);
  }

  // 2. Fake Phrases (-15 penalty)
  let fakeDensity = fakeCount / reviewCount;
  if (fakeDensity > 0.3) {
    modifier -= 15;
    reasoning.push(`High density (${Math.round(fakeDensity*100)}%) of templated fake-review phrases ("highly recommend", "must buy").`);
  }

  // 3. Short / Vague (-15 penalty)
  let shortRatio = shortCount / reviewCount;
  if (shortRatio > 0.5) {
    modifier -= 15;
    reasoning.push(`Many reviews (${Math.round(shortRatio*100)}%) are suspiciously short or vague, indicating lazy bot activity.`);
  }

  // 4. Exclamation Overuse (-10 penalty)
  let avgExclamation = exclamationCount / reviewCount;
  if (avgExclamation > 2) {
    modifier -= 10;
    reasoning.push(`Overuse of exclamation marks detected in reviews, common in paid or enthusiastic fake reviews.`);
  }

  // 5. Duplicates (-25 penalty max)
  if (duplicates > 0) {
    modifier -= 15 * Math.min(duplicates, 2);
    reasoning.push(`Detected ${duplicates} near-duplicate reviews using Jaccard similarity, indicating review recycling/bot activity.`);
  }

  // Bonus for genuine specific reviews
  if (foundCons.size > 0 && fakeDensity < 0.35 && duplicates === 0) {
    modifier += 15;
  }

  // Generate Review-Based Summary
  let summary = `AI Review Analysis (${reviewCount} samples): `;
  if (positiveCount >= negativeCount * 2) {
    summary += `Overall sentiment is highly positive. `;
  } else if (negativeCount > positiveCount) {
    summary += `Overall sentiment is negative. `;
  } else {
    summary += `Sentiment is mixed. `;
  }
  
  if (foundCons.size > 0) {
    summary += `Buyers highlighted concerns regarding: ${Array.from(foundCons).join(', ')}.`;
  } else if (fakeDensity < 0.3 && duplicates === 0) {
    summary += `Language patterns suggest genuine, organic feedback.`;
  }
  
  // Put the summary at the *start* of the review reasoning
  reasoning.unshift(summary.trim());

  return {
    scoreModifier: Math.round(modifier),
    reasoning: reasoning,
    cons: Array.from(foundCons)
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM BASELINE ALGORITHMS
// ─────────────────────────────────────────────────────────────────────────────

function analyzeCuratedPlatform(data, parsedCount, ratingNum, hasRating) {
  let trustScore = 50;
  let reasoning = [];
  const platform = data.platform || '';
  const seller = data.seller || '';

  trustScore += 20;
  reasoning.push(`${platform} is a curated fashion marketplace — platform trust is based on brand verification.`);
  
  trustScore += 10;
  reasoning.push(`Brand "${seller}" is an approved ${platform} partner.`);

  if (!hasRating) {
    reasoning.push(`No ratings yet — new listings on ${platform} are normal without reviews.`);
  } else if (parsedCount < 20) {
    reasoning.push(`${parsedCount} reviews at ${ratingNum}⭐. Low counts are common on ${platform} for niche fashion SKUs.`);
  } else {
    trustScore += 5;
    if (ratingNum >= 4.0) trustScore += 10;
    else if (ratingNum < 3.5) trustScore -= 15;
  }

  let discountNum = parseInt((data.discount || '').replace(/[^0-9]/g, '')) || 0;
  if (discountNum > 80) {
    trustScore -= 5;
  }

  return { trustScore, reasoning };
}

function analyzeMarketplace(data, tier, parsedCount, ratingNum, hasRating) {
  let trustScore = 50;
  let reasoning = [];
  const platform = data.platform || '';
  const seller = data.seller || '';

  if (tier === 'managed') {
    trustScore += 15; 
    reasoning.push(`${platform} provides managed logistics and buyer protection.`);
    trustScore += 10;
    reasoning.push(`Seller ships via ${platform}'s managed fulfilment network.`);
  } else {
    const knownMajor = ['Amazon', 'Flipkart'].includes(platform);
    if (knownMajor) {
      trustScore += 10; 
    } else {
      trustScore -= 15;
    }
    const s = seller.toLowerCase();
    if (s && s !== 'unknown') {
      trustScore += 5; 
    } else {
      trustScore -= 25;
      reasoning.push(`Seller identity hidden or unknown.`);
    }
  }

  if (!hasRating) {
    trustScore -= 30;
    reasoning.push(`No verified ratings found. Zero volume on an open marketplace is risky.`);
  } else {
    if (parsedCount < 10) {
      trustScore -= 20;
    } else if (parsedCount < 50) {
      trustScore -= 5;
    } else if (parsedCount < 200) {
      trustScore += 10;
    } else if (parsedCount < 1000) {
      trustScore += 20;
    } else {
      trustScore += 25; 
    }

    if (ratingNum >= 4.5) trustScore += 15;
    else if (ratingNum >= 4.0) trustScore += 10;
    else if (ratingNum < 3.5) trustScore -= 20;
  }

  let discountNum = parseInt((data.discount || '').replace(/[^0-9]/g, '')) || 0;
  if (discountNum > 60 && parsedCount < 50) trustScore -= 25;
  else if (discountNum > 70) trustScore -= 10;

  return { trustScore, reasoning };
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN ANALYSIS ENTRY
// ─────────────────────────────────────────────────────────────────────────────
function mockAiAnalysis(data) {
  const platform = data.platform || '';
  const seller   = data.seller   || '';
  const tier     = getPlatformTier(platform, seller);

  const reviewText  = data.reviewCount || '';
  const parsedCount = parseInt(reviewText.replace(/[^0-9]/g, '')) || 0;
  const ratingNum   = parseFloat(data.rating);
  const hasRating   = !isNaN(ratingNum) && parsedCount > 0;

  let analysis;
  if (tier === 'curated') {
    analysis = analyzeCuratedPlatform(data, parsedCount, ratingNum, hasRating);
  } else {
    analysis = analyzeMarketplace(data, tier, parsedCount, ratingNum, hasRating);
  }

  let trustScore = analysis.trustScore;
  let reasoning = analysis.reasoning;
  let cons = [];

  // DIRECT REVIEW CONTENT ANALYSIS
  if (data.reviews && data.reviews.length > 0) {
    const reviewData = analyzeReviewContent(data.reviews);
    trustScore += reviewData.scoreModifier;
    
    if (reviewData.reasoning.length > 0) {
      // Prioritize review analysis by putting it at the front of the reasoning text
      reasoning = reviewData.reasoning.concat(reasoning);
    }
    if (reviewData.cons.length > 0) {
      cons = reviewData.cons;
    }
  } else if (hasRating) {
    // If we have ratings but no text reviews were scraped
    // Silently skip adding reasoning about missing review texts
  }

  // Title Scam Heuristics
  if (data.title) {
    const t = data.title.toLowerCase();
    if (t.length > 120) trustScore -= 10;
    if (t.includes('[original]') || t.includes('100% genuine')) trustScore -= 20;
    const typoRegex = /\b(budss|cmff|airpodds|iphonn|sammsung|appple)\b/i;
    if (typoRegex.test(t)) trustScore -= 30;
  }

  trustScore = Math.max(1, Math.min(99, trustScore));
  const deliveryTrust = analyzeDeliveryAndReturns(data, tier, trustScore, parsedCount, ratingNum, hasRating);

  if (reasoning.length === 0) {
    if (hasRating && (!data.reviews || data.reviews.length === 0)) {
      reasoning.push(`Analysis is based on overall volume and seller reputation. Scroll down the product page to load the text reviews and try again for a deeper AI analysis.`);
    } else {
      reasoning.push(`Product metrics appear standard, with no major red flags detected.`);
    }
  }

  return {
    trustScore,
    reasoning: reasoning.join(' '),
    delivery: deliveryTrust,
    concerns: cons // Passing identified specific concerns
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// DELIVERY / RETURNS / REFUND ANALYSIS  — tier-aware
// ─────────────────────────────────────────────────────────────────────────────
function analyzeDeliveryAndReturns(data, tier, trustScore, parsedCount, ratingNum, hasRating) {
  const platform = data.platform || '';
  const seller   = (data.seller || '').toLowerCase();

  // Star calculator
  function calcStars(bonus = 0) {
    if (!hasRating) {
      return tier === 'curated' ? 3.0 : 1.0;
    }
    const base = Math.min(ratingNum, 5);
    let vol;
    if (tier === 'curated') {
      if (parsedCount === 0)       vol = 0.80; 
      else if (parsedCount < 10)   vol = 0.82;
      else if (parsedCount < 50)   vol = 0.88;
      else if (parsedCount < 200)  vol = 0.94;
      else                         vol = 1.00;
    } else if (tier === 'managed') {
      if (parsedCount < 10)        vol = 0.60;
      else if (parsedCount < 50)   vol = 0.72;
      else if (parsedCount < 200)  vol = 0.84;
      else if (parsedCount < 1000) vol = 0.94;
      else                         vol = 1.00;
    } else {
      if (parsedCount < 10)        vol = 0.45;
      else if (parsedCount < 50)   vol = 0.58;
      else if (parsedCount < 200)  vol = 0.76;
      else if (parsedCount < 1000) vol = 0.92;
      else                         vol = 1.00;
    }
    let stars = base * vol + bonus;
    return Math.round(Math.max(1, Math.min(5, stars)) * 2) / 2;
  }

  const isFBADelivery = platform === 'Amazon' && (
    seller.includes('amazon') || seller.includes('appario') || seller.includes('cocoblu') ||
    seller.includes('clicktech') || seller.includes('retailnet')
  );

  const deliveryStars = calcStars(isFBADelivery ? 0.4 : 0);
  const returnStars   = calcStars(['Amazon','Flipkart','Myntra','Ajio'].includes(platform) ? 0.2 : 0);
  const refundStars   = calcStars(0);

  // Delivery label
  let deliveryLabel, deliveryStatus, deliveryNote;
  if (tier === 'curated') {
    if (!hasRating) {
      deliveryLabel = 'Platform Managed'; deliveryStatus = 'ok';
      deliveryNote = `${platform} handles all deliveries through its own logistics.`;
    } else if (ratingNum >= 4.0) {
      deliveryLabel = 'On Time'; deliveryStatus = 'ok';
      deliveryNote = `${platform}'s in-house logistics indicate timely delivery.`;
    } else if (ratingNum >= 3.2) {
      deliveryLabel = 'Generally On Time'; deliveryStatus = 'ok';
      deliveryNote = `Delivery is managed by ${platform} — occasional delays possible.`;
    } else {
      deliveryLabel = 'Some Complaints'; deliveryStatus = 'bad';
      deliveryNote = `Despite platform logistics, some buyers have flagged delivery issues.`;
    }
  } else if (tier === 'managed') {
    if (!hasRating) {
      deliveryLabel = 'Logistics Managed'; deliveryStatus = 'ok';
      deliveryNote = `${isFBADelivery ? 'Fulfilled by Amazon' : `${platform} managed`} — delivery is handled by the platform.`;
    } else if (parsedCount < 10) {
      deliveryLabel = 'Limited Signals'; deliveryStatus = 'ok';
      deliveryNote = `Platform manages delivery so seller-level data is less critical here.`;
    } else if (ratingNum >= 4.2) {
      deliveryLabel = 'Reliable Track Record'; deliveryStatus = 'ok';
      deliveryNote = `Delivery consistently rated as satisfactory.`;
    } else if (ratingNum >= 3.5) {
      deliveryLabel = 'Moderate Consistency'; deliveryStatus = 'ok';
      deliveryNote = `Some variability expected.`;
    } else {
      deliveryLabel = 'Documented Complaints'; deliveryStatus = 'bad';
      deliveryNote = `Buyers have raised delivery concerns despite managed logistics.`;
    }
  } else {
    if (!hasRating) {
      deliveryLabel = 'Unverified'; deliveryStatus = 'bad';
      deliveryNote = 'No reviews to assess delivery. Treat as unverified.';
    } else if (parsedCount < 10) {
      deliveryLabel = 'Suspicious'; deliveryStatus = 'bad';
      deliveryNote = `Too few reviews to draw conclusions about delivery.`;
    } else if (parsedCount < 50) {
      deliveryLabel = ratingNum >= 4.0 ? 'Limited Data' : 'Mixed Signals';
      deliveryStatus = ratingNum >= 4.0 ? 'ok' : 'bad';
      deliveryNote = ratingNum >= 4.0
        ? `May not be representative.`
        : `Delivery consistency is questionable.`;
    } else if (ratingNum >= 4.2) {
      deliveryLabel = 'Mostly On Time'; deliveryStatus = 'ok';
      deliveryNote = `Buyers broadly satisfied with delivery.`;
    } else if (ratingNum >= 3.5) {
      deliveryLabel = 'Inconsistent'; deliveryStatus = 'ok';
      deliveryNote = `Delivery experience varies by order.`;
    } else {
      deliveryLabel = 'Frequent Issues'; deliveryStatus = 'bad';
      deliveryNote = `Buyers report delivery problems.`;
    }
  }

  // Returns label
  let returnLabel, returnStatus, returnNote;
  const platformReturnWindow = { Amazon: '10-Day Returns', Flipkart: '7-Day Returns', Myntra: '14-Day Returns', Ajio: '15-Day Returns' };
  const returnWindow = platformReturnWindow[platform];

  if (!returnWindow) {
    if (trustScore < 40) { returnLabel = 'No Clear Policy'; returnStatus = 'bad'; returnNote  = 'Return requests may go unanswered.'; }
    else { returnLabel = 'Policy Unclear'; returnStatus = 'ok'; returnNote  = 'Return terms not verified. Check before purchasing.'; }
  } else if (tier === 'curated') {
    if (!hasRating || parsedCount < 5) { returnLabel = returnWindow; returnStatus = 'ok'; returnNote = `${platform} enforces its own return policy directly.`; }
    else if (ratingNum < 3.5 && parsedCount >= 20) { returnLabel = `${returnWindow} — Check Reviews`; returnStatus = 'ok'; returnNote = `Policy is platform-enforced, but rating suggests some friction.`; }
    else { returnLabel = returnWindow; returnStatus = 'ok'; returnNote = `${platform} directly manages returns.`; }
  } else if (!hasRating || parsedCount === 0) {
    returnLabel = `${returnWindow} — Unverified`; returnStatus = 'bad'; returnNote = `Policy exists but no reviews confirm compliance.`;
  } else if (parsedCount < 10) {
    returnLabel = `${returnWindow} — Sparse Data`; returnStatus = 'bad'; returnNote = `Can't confirm return compliance.`;
  } else if (ratingNum < 3.5 && parsedCount >= 50) {
    returnLabel = `${returnWindow} — Disputed`; returnStatus = 'bad'; returnNote = `Rating suggests return friction.`;
  } else if (parsedCount >= 200 && ratingNum >= 4.0) {
    returnLabel = returnWindow; returnStatus = 'ok'; returnNote = `Returns processed as expected.`;
  } else {
    returnLabel = `${returnWindow} — Partially Verified`; returnStatus = 'ok'; returnNote = `Policy applies.`;
  }

  // Refund label
  let refundLabel, refundStatus, refundNote;
  const refundTimeline = { Amazon: '3–5 business days', Flipkart: '5–7 business days', Myntra: '7–10 days or wallet', Ajio: '7–10 days or wallet' }[platform];

  if (!refundTimeline) {
    if (trustScore < 40) { refundLabel = 'High Refund Risk'; refundStatus = 'bad'; refundNote = 'Prefer cash-on-delivery if possible.'; }
    else { refundLabel = 'Unconfirmed'; refundStatus = 'ok'; refundNote = 'Refund process not verified.'; }
  } else if (tier === 'curated') {
    if (!hasRating || parsedCount < 5) { refundLabel = refundTimeline.includes('wallet') ? 'Instant / Refund' : `Within ${refundTimeline}`; refundStatus = 'ok'; refundNote = `${platform} processes refunds centrally.`; }
    else if (ratingNum < 3.5 && parsedCount >= 20) { refundLabel = `${refundTimeline} — Check Reviews`; refundStatus = 'ok'; refundNote = `Refunds are platform-managed, but check recent buyer comments.`; }
    else { refundLabel = refundTimeline.includes('wallet') ? 'Instant / Refund' : `Within ${refundTimeline}`; refundStatus = 'ok'; refundNote = `${platform} manages refunds end-to-end.`; }
  } else if (!hasRating || parsedCount === 0) {
    refundLabel = 'No Review Basis'; refundStatus = 'bad'; refundNote = `Expected within ${refundTimeline} but no reviews confirm this.`;
  } else if (parsedCount < 10) {
    refundLabel = 'Unverifiable'; refundStatus = 'bad'; refundNote = `Can't determine refund reliability.`;
  } else if (ratingNum < 3.5 && parsedCount >= 50) {
    refundLabel = 'Likely Disputed'; refundStatus = 'bad'; refundNote = `Buyers may have experienced refund friction.`;
  } else if (parsedCount >= 200 && ratingNum >= 4.0) {
    refundLabel = `Within ${refundTimeline}`; refundStatus = 'ok'; refundNote = `Minimal refund friction.`;
  } else {
    refundLabel = `~${refundTimeline}`; refundStatus = 'ok'; refundNote = `Platform policy applies.`;
  }

  return {
    delivery: { label: deliveryLabel, status: deliveryStatus, note: deliveryNote, stars: deliveryStars },
    returns:  { label: returnLabel,   status: returnStatus,   note: returnNote,   stars: returnStars  },
    refund:   { label: refundLabel,   status: refundStatus,   note: refundNote,   stars: refundStars  }
  };
}
