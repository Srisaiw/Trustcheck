// This script runs in the context of the web page to extract product details

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extract_product_data") {
    try {
      const data = extractData();
      if (!data.title) {
        sendResponse({ error: "No product title found." });
      } else {
        sendResponse({ data: data });
      }
    } catch (err) {
      sendResponse({ error: err.message });
    }
    return true;
  }
});

function extractData() {
  const url = window.location.href;
  let platform = 'Unknown';
  let title = '';
  let seller = '';
  let rating = '';
  let reviewCount = '';
  let discount = '';
  let reviews = [];

  // Simple heuristic based extraction
  if (url.includes('amazon.')) {
    platform = 'Amazon';
    title = document.querySelector('#productTitle')?.innerText.trim() || '';
    const sellerCandidates = [
      document.querySelector('#sellerProfileTriggerId')?.innerText.trim(),
      document.querySelector('#tabular-buybox-truncate-1 .a-truncate-cut')?.innerText.trim(),
      document.querySelector('#merchant-info a')?.innerText.trim(),
      document.querySelector('#bylineInfo')?.innerText.trim()
    ];
    // Find the first valid seller string that isn't a generic "learn more" link
    seller = sellerCandidates.find(s => s && !s.toLowerCase().includes('learn more')) || 'Amazon/Unknown';

    // In case the seller name contains "Visit the ... Store", extract the brand name
    if (seller.startsWith('Visit the ') && seller.endsWith(' Store')) {
        seller = seller.replace('Visit the ', '').replace(' Store', '');
    }

    rating = document.querySelector('#acrPopover')?.getAttribute('title')?.split(' ')[0] || '';
    
    // Robust volume extraction to get just the first number and avoid concatenating
    const amzVolumeText = document.querySelector('#acrCustomerReviewText')?.innerText || 
                          document.querySelector('[data-hook="total-review-count"]')?.innerText || '';
    const amzMatch = amzVolumeText.match(/[\d,]+/);
    reviewCount = amzMatch ? amzMatch[0] : '';

    discount = document.querySelector('.savingsPercentage')?.innerText.trim() ||
      document.querySelector('span.savingPriceOverride')?.innerText.trim() || '';

    // Extract Amazon reviews
    const reviewElements = document.querySelectorAll(
      '[data-hook="review-body"], div[data-hook="reviewText"], .review-text-content, .a-expander-content.reviewText, div[data-hook="review-collapsed"], .review-text'
    );
    reviewElements.forEach(el => {
      const text = el.innerText.trim();
      if (text && reviews.length < 20 && !reviews.includes(text)) {
        reviews.push(text);
      }
    });
  }
  else if (url.includes('ebay.')) {
    platform = 'eBay';
    title = document.querySelector('.x-item-title__mainTitle .ux-textspans')?.innerText.trim() || '';
    seller = document.querySelector('.x-sellercard-atf__info__about-seller')?.getAttribute('title') ||
      document.querySelector('.x-sellercard-atf__info .ux-textspans')?.innerText.trim() ||
      'Unknown';
    rating = document.querySelector('.x-sellercard-atf__about-seller span:nth-child(2)')?.innerText.trim() || '';
    reviewCount = '';
  }
  else if (url.includes('flipkart.')) {
    platform = 'Flipkart';
    title = document.querySelector('.B_NuCI')?.innerText.trim() || document.querySelector('span.VU-ZEz')?.innerText.trim() || '';
    seller = document.querySelector('#sellerName span span')?.innerText.trim() || 'Unknown';
    rating = document.querySelector('div._3LWZlK')?.innerText.trim() || document.querySelector('div.XQDdHH')?.innerText.trim() || '';
    
    // Robust volume extraction to avoid concatenating Ratings & Reviews digits
    const flipkartVolumeText = document.querySelector('span._2_R_DZ')?.innerText || document.querySelector('span.Wphh3N')?.innerText || '';
    const flipkartMatch = flipkartVolumeText.match(/[\d,]+/);
    reviewCount = flipkartMatch ? flipkartMatch[0] : '';

    discount = document.querySelector('div._3Ay6Sb span')?.innerText.trim() || document.querySelector('div.UkUFwK span')?.innerText.trim() || '';

    // Extract Flipkart reviews
    document.querySelectorAll('div.t-ZTKy div div').forEach(el => {
      if (reviews.length < 20) reviews.push(el.innerText.trim());
    });
  }
  else if (url.includes('myntra.')) {
    platform = 'Myntra';
    const brand = document.querySelector('.pdp-title')?.innerText.trim() || '';
    const name = document.querySelector('.pdp-name')?.innerText.trim() || '';
    title = brand ? `${brand} - ${name}` : (name || document.title);
    seller = brand || 'Myntra Verified';

    const allTextNodes = Array.from(document.querySelectorAll('div, span'));
    const ratingNode = allTextNodes.find(el => el.innerText && el.innerText.includes('Ratings') && el.innerText.includes('|') && el.innerText.length < 30);
    if (ratingNode) {
      const parts = ratingNode.innerText.split('|');
      rating = parts[0].replace(/[^0-9.]/g, '');
      reviewCount = parts[1].replace(/[^0-9]/g, '');
    }
    discount = document.querySelector('.pdp-discount')?.innerText.trim() || '';

    // Extract Myntra reviews
    document.querySelectorAll('.user-review-reviewTextWrapper').forEach(el => {
      if (reviews.length < 20) reviews.push(el.innerText.trim());
    });
  }
  else if (url.includes('ajio.')) {
    platform = 'Ajio';
    const brand = document.querySelector('h2.brand-name')?.innerText.trim() || document.querySelector('.brand-name')?.innerText.trim() || '';
    const name = document.querySelector('h1.prod-name')?.innerText.trim() || document.querySelector('.prod-name')?.innerText.trim() || '';
    title = brand ? `${brand} - ${name}` : (name || document.title);
    seller = brand || 'Ajio Verified';

    // Ajio ratings (if present)
    const ratingNode = document.querySelector('.prod-rating');
    if (ratingNode) {
      rating = ratingNode.innerText.replace(/[^0-9.]/g, '');
    }
    const countNode = document.querySelector('.prod-rating-count') || document.querySelector('.rating-count');
    if (countNode) {
      reviewCount = countNode.innerText.replace(/[^0-9]/g, '');
    }

    discount = document.querySelector('.discount-desc')?.innerText.trim() || document.querySelector('.prod-discount')?.innerText.trim() || '';

    // Extract Ajio reviews
    document.querySelectorAll('.review-desc, .review-text').forEach(el => {
      if (reviews.length < 20) reviews.push(el.innerText.trim());
    });
  }
  else {
    // Generic fallback
    if (!title) title = document.querySelector('meta[property="og:title"]')?.getAttribute('content') || document.title;
    platform = new URL(url).hostname;
  }
  return {
    platform,
    title,
    seller,
    rating,
    reviewCount,
    discount,
    reviews,
    url
  };
}
