// This script runs in the context of the web page to extract product details

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extract_product_data") {
    try {
      const data = extractData();
      if (!data.title) {
        sendResponse({ error: "No product title found." });
      } else {
        sendResponse({ data: data });
      }
    } catch (err) {
      sendResponse({ error: err.message });
    }
    return true;
  }
});

function extractData() {
  const url = window.location.href;
  let platform = 'Unknown';
  let title = '';
  let seller = '';
  let rating = '';
  let reviewCount = '';
  let discount = '';

  // Simple heuristic based extraction
  if (url.includes('amazon.')) {
    platform = 'Amazon';
    title = document.querySelector('#productTitle')?.innerText.trim() || '';
    seller = document.querySelector('#sellerProfileTriggerId')?.innerText.trim() || 
             document.querySelector('#merchant-info a')?.innerText.trim() || 
             document.querySelector('#bylineInfo')?.innerText.trim() ||
             'Amazon/Unknown';
    rating = document.querySelector('#acrPopover')?.getAttribute('title')?.split(' ')[0] || '';
    reviewCount = document.querySelector('#acrCustomerReviewText')?.innerText.trim() || '';
    discount = document.querySelector('.savingsPercentage')?.innerText.trim() || 
               document.querySelector('span.savingPriceOverride')?.innerText.trim() || '';
  } 
  else if (url.includes('ebay.')) {
    platform = 'eBay';
    title = document.querySelector('.x-item-title__mainTitle .ux-textspans')?.innerText.trim() || '';
    seller = document.querySelector('.x-sellercard-atf__info__about-seller')?.getAttribute('title') || 
             document.querySelector('.x-sellercard-atf__info .ux-textspans')?.innerText.trim() || 
             'Unknown';
    rating = document.querySelector('.x-sellercard-atf__about-seller span:nth-child(2)')?.innerText.trim() || '';
    reviewCount = '';
  }
  else if (url.includes('flipkart.')) {
    platform = 'Flipkart';
    title = document.querySelector('.B_NuCI')?.innerText.trim() || document.querySelector('span.VU-ZEz')?.innerText.trim() || '';
    seller = document.querySelector('#sellerName span span')?.innerText.trim() || 'Unknown';
    rating = document.querySelector('div._3LWZlK')?.innerText.trim() || '';
    reviewCount = document.querySelector('span._2_R_DZ span span:first-child')?.innerText.trim() || '';
    discount = document.querySelector('div._3Ay6Sb span')?.innerText.trim() || '';
  }
  else if (url.includes('myntra.')) {
    platform = 'Myntra';
    const brand = document.querySelector('.pdp-title')?.innerText.trim() || '';
    const name = document.querySelector('.pdp-name')?.innerText.trim() || '';
    title = brand ? `${brand} - ${name}` : (name || document.title);
    seller = brand || 'Myntra Verified'; 
    
    const allTextNodes = Array.from(document.querySelectorAll('div, span'));
    const ratingNode = allTextNodes.find(el => el.innerText && el.innerText.includes('Ratings') && el.innerText.includes('|') && el.innerText.length < 30);
    if (ratingNode) {
      const parts = ratingNode.innerText.split('|');
      rating = parts[0].replace(/[^0-9.]/g, '');
      reviewCount = parts[1].replace(/[^0-9]/g, '');
    }
    discount = document.querySelector('.pdp-discount')?.innerText.trim() || '';
  }
  else if (url.includes('ajio.')) {
    platform = 'Ajio';
    const brand = document.querySelector('h2.brand-name')?.innerText.trim() || document.querySelector('.brand-name')?.innerText.trim() || '';
    const name = document.querySelector('h1.prod-name')?.innerText.trim() || document.querySelector('.prod-name')?.innerText.trim() || '';
    title = brand ? `${brand} - ${name}` : (name || document.title);
    seller = brand || 'Ajio Verified'; 
    
    // Ajio ratings (if present)
    const ratingNode = document.querySelector('.prod-rating');
    if (ratingNode) {
      rating = ratingNode.innerText.replace(/[^0-9.]/g, '');
    }
    const countNode = document.querySelector('.prod-rating-count') || document.querySelector('.rating-count');
    if (countNode) {
      reviewCount = countNode.innerText.replace(/[^0-9]/g, '');
    }
    
    discount = document.querySelector('.discount-desc')?.innerText.trim() || document.querySelector('.prod-discount')?.innerText.trim() || '';
  }
  else {
    // Generic fallback
    if (!title) title = document.querySelector('meta[property="og:title"]')?.getAttribute('content') || document.title;
    platform = new URL(url).hostname;
  }

  return {
    platform,
    title,
    seller,
    rating,
    reviewCount,
    discount,
    url
  };
}
